<div class="row-fluid">
					<div class="span12">
						<!-- BEGIN VALIDATION STATES-->
						<div class="portlet box blue">
							<div class="portlet-title">
								<div class="caption"><i class="icon-reorder"></i>Laporan</div>
								<div class="tools">
									<a href="javascript:;" class="collapse"></a>
									
								</div>
							</div>
							<div class="portlet-body form">
								<!-- BEGIN FORM-->
								<?php if(validation_errors()) { ?>
								<div class="alert alert-block alert-error">
								  <button type="button" class="close" data-dismiss="alert">×</button>
									<?php echo validation_errors(); ?>
								</div>
								<?php 
								} 
								?>

								<div id="form_sample_2" class="form-horizontal">
								
									<?php echo form_open_multipart('adminweb/cetak_laporan/','class="form-horizontal"'); ?>
									
									<div class="control-group">
										<label class="control-label">Dari Tanggal</label>
										<div class="controls">
											<input type="date" name="dari"  class="span6 m-wrap"  />
										</div>
									</div>

									<div class="control-group">
										<label class="control-label">Sampai Tanggal</label>
										<div class="controls">
											<input type="date" name="sampai"  class="span6 m-wrap" />
										</div>
									</div>
											

									
									<div class="form-actions">
										<button type="submit" id="simpan" class="btn green"><i class="icon-ok"></i> Lihat</button>
										<a href="<?php echo base_url();?>adminweb/produk" class="btn whitbtne"> Batal</a>
										
									</div>
									<?php echo form_close(); ?>
								</div>
								
							</div>
						</div>
						
					</div>
				</div>


