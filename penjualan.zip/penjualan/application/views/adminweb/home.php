<div class="clearfix"></div>
          <div class="row-fluid">
            
            <div class="span12">
              <div class="portlet box blue">
                <div class="portlet-title">
                  <div class="caption"><i class="icon-calendar"></i>Sistem Informasi Pemesanan Dedi Catering</div>
                  <div class="tools">
                    <a href="" class="collapse"></a>
                    
                  </div>
                </div>
                <div class="portlet-body">
                  <div class="row-fluid">
                    <div class="alert">
                      <p>Hallo! Selamat Datang,</p>
                      <p>Silahkan akses sistem sesuai dengan kebutuhan. Demi keamanan sistem, update password secara berkala</p>

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="clearfix"></div>